package e.com.customgridview;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.view.menu.ActionMenuItemView;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListAdapter;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    GridView gridView;

    String letterList[] = { "eclair","froyo","ginger bread","Honey comb","icecream","jellybean","lollipop","marshmallow","nougat"};
    int lettersIcon[]= {R.drawable.eclair, R.drawable.froyo,R.drawable.gingerbread,R.drawable.honeycomb,R.drawable.icecream,R.drawable.jellybean,
            R.drawable.lollipop,R.drawable.marshmallow,R.drawable.nougat};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        gridView = (GridView) findViewById(R.id.gridview);

        GridAdapter adapter = new GridAdapter(MainActivity.this,lettersIcon,letterList);

        gridView.setAdapter(adapter);

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Toast.makeText(MainActivity.this,"clicked Letter :" +letterList[position] , Toast.LENGTH_SHORT).show();


            }
        });
    }
}
