package e.com.customgridview;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by sandy on 6/13/2017.
 */

public class GridAdapter extends BaseAdapter {

    private int Icons[];

    private String letter[];

    private Context context;

    private LayoutInflater inflater;


    public GridAdapter(Context context,int Icons[],String letters[] ){

        this.context=context;
        this.Icons=Icons;
        this.letter =letters;
    }

    @Override
    public int getCount() {
        return letter.length;
    }

    @Override
    public Object getItem(int position) {
        return letter[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View gridview = convertView;

                if(convertView==null){
            inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            gridview = inflater.inflate(R.layout.custom_layout,null);
                }

        ImageView Icon = (ImageView) gridview.findViewById(R.id.Icons);
        TextView letters = (TextView) gridview.findViewById(R.id.letter);

        Icon.setImageResource(Icons[position]);
        letters.setText(letter[position]);

        return gridview;
    }
}
